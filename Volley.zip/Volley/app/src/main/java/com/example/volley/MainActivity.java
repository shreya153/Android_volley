package com.example.volley;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {
    EditText username, email, password;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.unameInput);
        email = findViewById(R.id.emailinput);
        password = findViewById(R.id.pswordInput);
        String mailid = email.getText().toString();

        final TextView textView = (TextView) findViewById(R.id.text);

        Button button = findViewById(R.id.signInButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mailid.matches("^[a-z0-9.]+" +
                        "(?:\\." +"[a-z0-9]+) *@" +
                        "(?:[a-z0-9]+\\.)+[a-z" +
                        "A-Z]{2,7}$")){
                    saveUser(createRequest());
                }
                else{
                    email.setError("Enter the valid email id");
                }
            }
        });


    }
    public UserRequest createRequest(){
        UserRequest userRequest = new UserRequest();
        userRequest.setEmail(email.getText().toString());
        userRequest.setFull_name(username.getText().toString());
        userRequest.setPassword(password.getText().toString());

        return userRequest;
    }

    public void saveUser(UserRequest userRequest){
        Call<UserResponse> userResponseCall = ApiClient.getUserService().saveUser(userRequest);
        userResponseCall.enqueue(new Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                if(response.isSuccessful()){
                    Toast.makeText(MainActivity.this, "Saved successfully", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Request failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UserResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Request failed"+t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


}